package Project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
public class Team {
    private ArrayList<Player> roster;
    private HashMap<String, ArrayList<Player>> starters;
    private HashMap<String, ArrayList<Player>> rankByPos;
    private int losses = 0;
    private int wins = 0;
 
    public Team() {
        roster = new ArrayList<Player>();
    }
    public void addPlayer(Player p) {
        roster.add(p);
    }

    public void wonGame() {
        wins++;
    }
    public void lossGame() {
        losses++;
    }
    public void playedGame() {
    	for(Player p: roster) 
    		p.playedGame();
    }
    public void printRecord() {
        System.out.println("Record: " + wins + "-" + losses);
    }
    public void rankPlayers() {
    	rankByPos = new HashMap<>();
    	for(Player p: roster) {
    		String pos = p.getPos();
    		if(!rankByPos.containsKey(pos)) {
    			rankByPos.put(pos, new ArrayList<Player>());
    		}
    		rankByPos.get(pos).add(p);
    	}
    	
    	for(String key: rankByPos.keySet()) {
    		ArrayList<Player> list = rankByPos.get(key);
    		Collections.sort(rankByPos.get(key));
    		for(int i = 0; i < rankByPos.get(key).size(); i++) {
    			System.out.println(rankByPos.get(key).get(i).getName());
    		}
    	}	
    }
    public void startingLineup() {
    	starters = new HashMap<>();
        for(Player p: roster) {
            String pos = p.getPos();
            if(!starters.containsKey(pos)) {
                starters.put(pos, new ArrayList<Player>());
            }
            starters.get(pos).add(p);
        }
        ArrayList<Player> finalStarters = new ArrayList<>();
        for(String pos: starters.keySet()) {
            ArrayList<Player> positionList = starters.get(pos);
            Player best = positionList.get(0);
            for(int i = 1; i < positionList.size(); i++) {
                if(best.playerValue() < positionList.get(i).playerValue()) {
                    best = positionList.get(i);
                }
            }
            finalStarters.add(best);
        }
        for(Player p: finalStarters) {
            System.out.println(p.getPos() + ": " + p.getName());
        }
    }
}