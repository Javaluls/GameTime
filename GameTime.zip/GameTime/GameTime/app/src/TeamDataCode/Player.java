package Project;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Owner on 10/28/2017.
 */

public abstract class Player implements Comparable{
    protected String name;
    protected String position;
    protected HashMap<String, int[]> stats;
    protected int games = 0;
    protected double playerVal;
    public Player() {
    	
    }

    public void printStats() {
        for(String key: stats.keySet()) {
            System.out.println(key + "/game: " + stats.get(key)[0]/(1.0 * games));
        }
    }

    public String getPos() {
        return position;
    }
 
    public String getName() {
        return name;
    }
    
    public void playedGame() {
    	games++;
    }
    public double playerValue() {
        return this.playerVal;
    }

    public void updateVal(){
    	
    } 
    
    public void update(String stat) {
        stats.get(stat)[0]++;
        this.updateVal();
    }
    public int compareTo(Object p) {
    	if(this.playerValue() == ((Player) p).playerValue())
    		return 0;
    	else if (this.playerValue() > ((Player) p).playerValue())
    		return -1;
    	else 
    		return 1;
    }
}