package Project;

import java.util.HashMap;

/**
 * Created by Owner on 10/28/2017.
 */

public class Player_Basketball extends Player {

    private HashMap<String, int[]> statList;
    public Player_Basketball(String n, String pos, int plays) {
    	name = n;
    	position = pos;
    	games = plays;
        stats = new HashMap<>();
        stats.put("PTS", new int[1]);
        stats.put("AST", new int[1]);
        stats.put("REB", new int[1]);
        stats.put("BLK", new int[1]);
        stats.put("STL", new int[1]);
        stats.put("TO", new int[1]);
        // Set starting value
        updateVal();
    }
    public Player_Basketball(String n, String pos, int plays, HashMap<String, int[]> info) {
        name = n;
        position = pos;
        games = plays;
        stats = info;
        updateVal();
    }
    public Player_Basketball(HashMap<String, int[]> p) {
    	statList = p;
    }
    public void updateVal() {
        double result = 0;
        result += stats.get("PTS")[0]; /// 1.5;
        result += stats.get("AST")[0];
        result += stats.get("REB")[0];
        result += stats.get("BLK")[0]; //* 2.0;
        result += stats.get("STL")[0]; //* 2.0;
        result -= stats.get("TO")[0]; /// 2.0;
        playerVal = result;
    }
    
}
