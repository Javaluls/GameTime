package comjavaluls.httpsgithub.gametime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class Home extends AppCompatActivity {

    public Button basket;

    public void basketInit() {
        basket = (Button) findViewById(R.id.basket);
        basket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Does the actual changing from page to page
                Intent goBasket = new Intent(Home.this, Basket_Ball_Home.class);
                startActivity(goBasket);
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        basketInit();
    }
}
