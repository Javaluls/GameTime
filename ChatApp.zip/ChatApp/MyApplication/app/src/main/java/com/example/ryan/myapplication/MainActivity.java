package com.example.ryan.myapplication;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView javaNumberTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        javaNumberTextView = (TextView)findViewById(R.id.textview);

        MediaPlayer mediaPlayer = MediaPlayer.create(getBaseContext(), R.raw.macintosh);
        mediaPlayer.start();
        //mediaPlayer.setNextMediaPlayer();
    }

    public void random(View view){
        int randomNum = (int) (Math.random() * 6) + 1;
        javaNumberTextView.setText("" + randomNum);
    }


}
